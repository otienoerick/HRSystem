import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const dataDir = resolve(process.env.DATA_DIR || resolve(root, 'data'));
mkdirSync(dataDir, { recursive: true });
const dbPath = resolve(dataDir, 'staff.sqlite');
const db = new DatabaseSync(dbPath);
try {
  db.exec(readFileSync(resolve(root, 'database/schema.sql'), 'utf8'));
  db.exec("INSERT OR IGNORE INTO roles(role_name,description) VALUES ('System Administrator','Full system administration'),('HR Officer','Staff and leave administration'),('Supervisor','First-stage leave review'),('Final Approver','Final leave decision'),('Employee','Own profile and leave requests'),('Auditor','Read-only audit access')");
  db.exec("INSERT OR IGNORE INTO leave_types(leave_code,leave_name,default_annual_entitlement,allow_half_day) VALUES ('ANNUAL','Annual Leave',0,1),('SICK','Sick Leave',0,0),('COMP','Compassionate Leave',0,0)");
  const tables = db.prepare("SELECT count(*) AS n FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").get().n;
  const roles = db.prepare('SELECT count(*) AS n FROM roles').get().n;
  const leaveTypes = db.prepare('SELECT count(*) AS n FROM leave_types').get().n;
  console.log(JSON.stringify({ database: dbPath, tables, roles, leaveTypes }));
} finally {
  db.close();
}
