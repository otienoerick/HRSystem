# Security notes

Implemented baseline controls: parameterized SQL, foreign keys, hashed passwords using scrypt, constant-time hash comparison, opaque random session identifiers, HttpOnly and SameSite=Strict cookies, no-store API responses, role-gated mutation routes, self-approval rejection, setup-token gate, server-side input validation, and audit records for selected actions. The app binds to loopback by default.

Before deployment: put a maintained reverse proxy in front with TLS, configure secure cookies, add CSRF defenses and login throttling, persist/expire/revoke sessions, enforce password reset and MFA policy, scan and isolate files, apply least privilege to database and media storage, redact logs, encrypt storage and backups, configure rate limits and security headers, patch Node regularly, conduct a threat model and penetration test, and document incident response and retention. Do not expose the setup token, SQLite file, or database service to the public network.

This starter does not establish compliance with Kenya's Data Protection Act or any institutional policy. Obtain a documented privacy and legal assessment for the institution's actual processing.
