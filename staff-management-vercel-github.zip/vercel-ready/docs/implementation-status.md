# Implementation report (2026-10-12)

## Included and implemented

- All 14 entities visible in the supplied ERD, foreign keys, basic uniqueness/check constraints, and common indexes.
- Secure password hashing (scrypt), initial administrator setup token, opaque HttpOnly/SameSite session cookie, and role checks for staff creation and approval stages.
- Staff directory read view and HR/admin create endpoint.
- Leave submission, supervisor → HR → final-approver stage transition, rejection comments, self-approval block, and final-stage debit ledger entry in a transaction.
- Audit records for initial admin, employee create, leave submission, and decisions.
- Responsive browser UI for login, overview, staff directory, leave queue, and leave application.
- ERD source and deployment/security notes.

## Not implemented; do not treat as acceptance complete

Excel/XLSX import and preview; employee edit/deactivation UI; complete user and role administration; account recovery, throttling and MFA; durable sessions and CSRF tokens; document binary upload/download and malware scanning; a configured supervisor/HR/final-approver assignment workflow; institutional work calendar and public holiday calculation; balance entitlement/accrual setup, reservations, reconciliation and reversal; notifications/email; dashboards beyond counts; CSV/XLSX/PDF exports; generated rendered ERD image; PostgreSQL migrations; Docker/Nginx/TLS production configuration; backups and restoration scripts; monitoring/log rotation; comprehensive API docs and role manuals; performance, penetration, and user acceptance testing.

The current debit calculation has no initialized balance model and can therefore produce a negative balance. The application accepts a requested working-day count from the client. Those behaviors are exposed as limitations and must be resolved before any operational use. No legal compliance claim is made.

## Verification

The included test suite checks SQLite schema creation, uniqueness, and foreign-key enforcement. It is not an end-to-end or security test suite. Run with `npm test` under Node.js 24 or newer.
