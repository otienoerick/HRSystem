# Local deployment guide

## Development

Use Node.js 24+. Run `npm start` in the project directory. Set `SETUP_TOKEN` to a high-entropy secret before first launch. The first admin setup endpoint requires that token and a password of at least 14 characters. Remove the token after setup. Set `DATA_DIR` to a protected persistent directory and `PORT` to a local port if needed.

## Server placement

The app listens on `127.0.0.1`, suitable for a local reverse proxy. Configure Nginx or an institutional reverse proxy to terminate HTTPS and forward requests to the loopback address. Permit inbound HTTPS only; do not expose the app or database file to the internet. The current implementation does not set `Secure` on cookies because TLS termination is outside the app; enable it before production.

## Data backup

Stop the app and copy the SQLite database to encrypted backup storage. Keep multiple dated copies, restrict access, and periodically restore a copy into an isolated environment to verify it. Production use requires an automated backup and tested recovery process, neither is bundled in this baseline.

## Capacity

No production capacity claim is made. The requested 1,500+ staff scale requires PostgreSQL, realistic load and concurrency tests, monitoring, and infrastructure sizing based on the institution's usage. The included SQLite implementation is for evaluation and development.
